﻿namespace JavaCSharp
{
    partial class Java8Parser
    {
    }
}
